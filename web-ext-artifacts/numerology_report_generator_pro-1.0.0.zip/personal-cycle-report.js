// Updated PDF generation function with proper spacing, padding, and all API fields
// Replace the createPersonalCyclePDF function in popup.js with this

async function createPersonalCyclePDF(data, clientData, targetYear, customization) {
    // Retry mechanism for jsPDF loading
    let jsPDF = null;
    let attempts = 0;
    const maxAttempts = 10;
    
    while (!jsPDF && attempts < maxAttempts) {
        if (window.jsPDF) {
            jsPDF = window.jsPDF;
        } else if (window.jspdf && window.jspdf.jsPDF) {
            jsPDF = window.jspdf.jsPDF;
            window.jsPDF = jsPDF;
        }
        
        if (!jsPDF) {
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }
    }
    
    if (!jsPDF) {
        throw new Error('jsPDF library failed to load after retries');
    }
    
    const doc = new jsPDF();
    
    let yPos = 20;
    const pageWidth = doc.internal.pageSize.width;
    const pageHeight = doc.internal.pageSize.height;
    const margin = 20;
    const contentWidth = pageWidth - (2 * margin);

    const checkNewPage = (neededHeight) => {
        if (yPos + neededHeight > pageHeight - margin) {
            doc.addPage();
            yPos = margin;
            return true;
        }
        return false;
    };

    // ========== COVER PAGE ==========
    doc.setFillColor(107, 70, 193);
    doc.rect(0, 0, pageWidth, 80, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(26);
    doc.setFont('helvetica', 'bold');
    const title = customization.title || 'Personal Cycle Analysis Report';
    doc.text(title, pageWidth / 2, 35, { align: 'center', maxWidth: contentWidth - 20 });
    
    yPos = 60;
    doc.setFontSize(48);
    doc.text(targetYear.toString(), pageWidth / 2, yPos, { align: 'center' });
    
    yPos = 105;
    
    // Client Information Box with proper padding
    const boxHeight = 70;
    doc.setFillColor(247, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(margin, yPos, contentWidth, boxHeight, 3, 3, 'FD');
    
    doc.setTextColor(26, 32, 44);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    
    yPos += 12;
    doc.text('Client Name:', margin + 10, yPos);
    doc.setFont('helvetica', 'normal');
    doc.text(clientData.name, margin + 60, yPos);
    
    yPos += 10;
    doc.setFont('helvetica', 'bold');
    doc.text('Date of Birth:', margin + 10, yPos);
    doc.setFont('helvetica', 'normal');
    doc.text(formatDate(clientData.dob), margin + 60, yPos);
    
    yPos += 10;
    doc.setFont('helvetica', 'bold');
    doc.text('Age in Target Year:', margin + 10, yPos);
    doc.setFont('helvetica', 'normal');
    doc.text(data.input.age_in_target_year.toString(), margin + 60, yPos);
    
    yPos += 10;
    doc.setFont('helvetica', 'bold');
    doc.text('Personal Year:', margin + 10, yPos);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(107, 70, 193);
    doc.text(data.personal_cycle.number.toString(), margin + 60, yPos);
    
    yPos += 10;
    doc.setTextColor(26, 32, 44);
    doc.setFont('helvetica', 'bold');
    doc.text('Universal Year:', margin + 10, yPos);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(107, 70, 193);
    doc.text(data.universal_cycle.number.toString(), margin + 60, yPos);
    
    yPos += 10;
    doc.setTextColor(26, 32, 44);
    doc.setFont('helvetica', 'bold');
    doc.text('Generated:', margin + 10, yPos);
    doc.setFont('helvetica', 'normal');
    doc.text(new Date().toLocaleDateString(), margin + 60, yPos);
    
    yPos += 80;
    doc.setFontSize(13);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(74, 85, 104);
    doc.text('Understanding Your Personal Journey Within the Universal Flow', 
        pageWidth / 2, yPos, { align: 'center', maxWidth: contentWidth });
    
    doc.addPage();
    yPos = margin;
    
    // ========== CYCLE SYNTHESIS ==========
    doc.setTextColor(107, 70, 193);
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text('Your Cycle Overview', margin, yPos);
    yPos += 12;
    
    doc.setTextColor(26, 32, 44);
    doc.setFontSize(13);
    doc.setFont('helvetica', 'normal');
    const overviewLines = doc.splitTextToSize(data.cycle_synthesis.overview, contentWidth);
    doc.text(overviewLines, margin, yPos);
    yPos += overviewLines.length * 6 + 10;
    
    checkNewPage(40);
    
    // Key Integration Box
    doc.setFillColor(255, 249, 230);
    doc.setDrawColor(217, 119, 6);
    doc.roundedRect(margin, yPos, contentWidth, 35, 3, 3, 'FD');
    
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text('Key Integration', margin + 5, yPos + 8);
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    const keyIntLines = doc.splitTextToSize(data.cycle_synthesis.key_integration, contentWidth - 10);
    doc.text(keyIntLines, margin + 5, yPos + 16);
    yPos += 40;
    
    checkNewPage(40);
    
    // Alignment Guidance Box
    doc.setFillColor(232, 245, 233);
    doc.setDrawColor(56, 161, 105);
    doc.roundedRect(margin, yPos, contentWidth, 35, 3, 3, 'FD');
    
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Alignment Guidance', margin + 5, yPos + 8);
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    const alignLines = doc.splitTextToSize(data.cycle_synthesis.alignment_guidance, contentWidth - 10);
    doc.text(alignLines, margin + 5, yPos + 16);
    yPos += 45;
    
    // ========== PERSONAL YEAR SECTION ==========
    doc.addPage();
    yPos = margin;
    
    const personal = data.personal_cycle.detailed_meaning;
    
    doc.setTextColor(107, 70, 193);
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text(`Personal Year ${data.personal_cycle.number}`, margin, yPos);
    yPos += 10;
    
    doc.setFontSize(14);
    doc.text(personal.title, margin, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(74, 85, 104);
    const meaningLines = doc.splitTextToSize(data.personal_cycle.meaning, contentWidth);
    doc.text(meaningLines, margin, yPos);
    yPos += meaningLines.length * 6 + 15;
    
    // Core Attributes
    doc.setTextColor(26, 32, 44);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Core Attributes', margin, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    
    const attributes = [
        ['Theme:', personal.theme],
        ['Energy:', personal.energy],
        ['Emo Tone:', personal.emotional_tone]
    ];
    
    attributes.forEach(([label, value]) => {
        checkNewPage(15);
        doc.setFont('helvetica', 'bold');
        doc.text(label, margin, yPos);
        doc.setFont('helvetica', 'normal');
        const valueLines = doc.splitTextToSize(value, contentWidth - 30);
        doc.text(valueLines, margin + 35, yPos);
        yPos += Math.max(valueLines.length * 5, 8);
    });
    
    yPos += 10;
    
    // Key Areas of Focus
    checkNewPage(50);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Key Areas of Focus', margin, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    personal.key_areas.forEach(area => {
        checkNewPage(10);
        doc.text('- ' + area, margin + 5, yPos);
        yPos += 7;
    });
    
    yPos += 10;
    
    // Opportunities & Challenges
    checkNewPage(40);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Opportunities & Challenges', margin, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Opportunities:', margin, yPos);
    doc.setFont('helvetica', 'normal');
    const oppLines = doc.splitTextToSize(personal.opportunities, contentWidth - 35);
    doc.text(oppLines, margin + 35, yPos);
    yPos += oppLines.length * 5 + 8;
    
    checkNewPage(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Challenges:', margin, yPos);
    doc.setFont('helvetica', 'normal');
    const chalLines = doc.splitTextToSize(personal.challenges, contentWidth - 35);
    doc.text(chalLines, margin + 35, yPos);
    yPos += chalLines.length * 5 + 8;
    
    // Action Steps with proper padding
    if (customization.includeActionSteps) {
        checkNewPage(60);
        
        const actionStepsHeight = 15 + (personal.action_steps.length * 7);
        doc.setFillColor(240, 244, 255);
        doc.setDrawColor(107, 70, 193);
        doc.roundedRect(margin, yPos, contentWidth, actionStepsHeight, 3, 3, 'FD');
        
        yPos += 10;
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(107, 70, 193);
        doc.text('Action Steps for This Year', margin + 5, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(26, 32, 44);
        personal.action_steps.forEach(step => {
            doc.text('- ' + step, margin + 8, yPos);
            yPos += 7;
        });
        
        yPos += 15;
    }
    
    // ========== LIFE AREAS DEEP DIVE ==========
    doc.addPage();
    yPos = margin;
    
    doc.setTextColor(107, 70, 193);
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text('Life Areas in Focus', margin, yPos);
    yPos += 15;
    
    const lifeAreas = [
        ['Career & Money', personal.career_money],
        ['Relationships', personal.relationships],
        ['Health & Wellness', personal.health_wellness],
        ['Spiritual Lesson', personal.spiritual_lesson]
    ];
    
    lifeAreas.forEach(([title, content]) => {
        checkNewPage(40);
        doc.setTextColor(26, 32, 44);
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text(title, margin, yPos);
        yPos += 8;
        
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        const contentLines = doc.splitTextToSize(content, contentWidth);
        doc.text(contentLines, margin, yPos);
        yPos += contentLines.length * 5 + 12;
    });
    
    // ========== UNIVERSAL YEAR SECTION ==========
    doc.addPage();
    yPos = margin;
    
    const universal = data.universal_cycle.detailed_meaning;
    
    doc.setTextColor(107, 70, 193);
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text(`Universal Year ${data.universal_cycle.number}`, margin, yPos);
    yPos += 10;
    
    doc.setFontSize(14);
    doc.text(universal.title, margin, yPos);
    yPos += 10;
    
    doc.setFontSize(13);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(74, 85, 104);
    const uMeaningLines = doc.splitTextToSize(data.universal_cycle.meaning, contentWidth);
    doc.text(uMeaningLines, margin, yPos);
    yPos += uMeaningLines.length * 6 + 15;
    
    // Global Energy Profile
    doc.setTextColor(26, 32, 44);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Global Energy Profile', margin, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    
    const universalAttrs = [
        ['Theme:', universal.theme],
        ['Energy:', universal.energy],
        ['Collective:', universal.collective_mood]
    ];
    
    universalAttrs.forEach(([label, value]) => {
        checkNewPage(15);
        doc.setFont('helvetica', 'bold');
        doc.text(label, margin, yPos);
        doc.setFont('helvetica', 'normal');
        const valueLines = doc.splitTextToSize(value, contentWidth - 35);
        doc.text(valueLines, margin + 35, yPos);
        yPos += Math.max(valueLines.length * 5, 8);
    });
    
    yPos += 10;
    
    // Global Focus Areas
    checkNewPage(50);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Global Focus Areas', margin, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    universal.global_focus.forEach(item => {
        checkNewPage(10);
        doc.text('- ' + item, margin + 5, yPos);
        yPos += 7;
    });
    
    yPos += 10;
    
    // Universal Guidance
    checkNewPage(60);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Universal Guidance', margin, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Opportunities:', margin, yPos);
    doc.setFont('helvetica', 'normal');
    const uOppLines = doc.splitTextToSize(universal.opportunities, contentWidth - 35);
    doc.text(uOppLines, margin + 35, yPos);
    yPos += 8;
    
    checkNewPage(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Challenges:', margin, yPos);
    doc.setFont('helvetica', 'normal');
    const uChalLines = doc.splitTextToSize(universal.challenges, contentWidth - 35);
    doc.text(uChalLines, margin + 35, yPos);
    yPos += 8;
    
    checkNewPage(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Advice:', margin, yPos);
    doc.setFont('helvetica', 'normal');
    const adviceLines = doc.splitTextToSize(universal.advice, contentWidth - 35);
    doc.text(adviceLines, margin + 35, yPos);
    yPos += 8;
    
    // ========== FOOTER ==========
    const footerY = pageHeight - 30;
    doc.setFillColor(248, 249, 250);
    doc.rect(0, footerY, pageWidth, 30, 'F');
    
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(149, 165, 166);
    
    const footerText = customization.branding || 
        `Generated by ${settings.practitionerName || 'Numerology Report Generator Pro'}`;
    doc.text(footerText, pageWidth / 2, footerY + 10, { align: 'center' });
    doc.text('Powered by The Numerology API - NumerologyAPI.com', 
        pageWidth / 2, footerY + 17, { align: 'center' });
    doc.text(`© ${new Date().getFullYear()} - For Personal Guidance Only`, 
        pageWidth / 2, footerY + 24, { align: 'center' });
    
    return doc;
}
